App({
  globalData: {
    mqttClient: null,
    mqttOptions: {
      protocolVersion: 4,
      clean: false,
      reconnectPeriod: 1000,
      connectTimeout: 30 * 1000,
      resubscribe: true,
      clientId: '',
      password: '',
      username: '',
    },
    aliyunInfo: {
      productKey: '',
      deviceName: '',
      deviceSecret: '',
      regionId: '',
      pubTopic: '',
      subTopic: ''
    },
    BoxSwitch:0,
    isConnected: false,
    FireWarning: 0,
    //FireWarning2: 1,
    //onFireWarningUpdate: null,
    BoxNumber: 0,
    countdown: '',
    alertShown: false,
    fiveMinuteAlertShown: false,
    chosenTime: null,
    countdownInterval: null
    },
    showFireWarningAlert: function (message) {
      wx.showModal({
        title: '火焰报警',
        content: message,
        showCancel: false,
        confirmText: '收到',
        success: function (res) {
          if (res.confirm) {
            console.log('用户点击了确定');
            // 用户点击确定后的操作
          }
        }
      });
    },
    eventEmitter: {
      handlers: {},
      on: function (eventName, callback) {
        if (!this.handlers[eventName]) {
          this.handlers[eventName] = [];
        }
        this.handlers[eventName].push(callback);
      },
      emit: function (eventName, data) {
        if (this.handlers[eventName]) {
          this.handlers[eventName].forEach(callback => callback(data));
        }
      }
    },
    startGlobalCountdown: function() {
      // 清除之前的倒计时
      clearInterval(this.globalData.countdownInterval);
  
      // 设置倒计时
      this.globalData.countdownInterval = setInterval(() => {
        this.updateGlobalCountdown();
      }, 1000);
    },
    updateGlobalCountdown: function() {
      const now = new Date().getTime();
      const chosenTime = this.globalData.chosenTime;
      const distance = chosenTime - now;
  
      // 如果已选择时间并且当前时间未超过选择的时间
      if (chosenTime && distance > 0) {
        // 计算倒计时时间
        const days = Math.floor(distance / (1000 * 60 * 60 * 24));
        const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((distance % (1000 * 60)) / 1000);
  
        let countdownStr = '';
  
        // 仅当天数大于0时添加天数的显示
        if (days > 0) {
          countdownStr += `${days}天 `;
        }
  
        // 仅当小时数大于0时添加小时数的显示
        if (hours > 0 || days > 0) {
          countdownStr += `${hours}小时 `;
        }
  
        // 仅当分钟数大于0时添加分钟数的显示
        if (minutes > 0 || hours > 0 || days > 0) {
          countdownStr += `${minutes}分钟 `;
        }
  
        // 秒数总是显示
        countdownStr += `${seconds}秒`;
  
        this.globalData.countdown = countdownStr;
  
        // 当倒计时小于10分钟且未弹出过警告时
        if (distance <= 600000 && !this.globalData.alertShown) {
          this.showGlobalAlert();
          this.globalData.alertShown = true;
        }
  
        // 当倒计时小于5分钟且未弹出过警告时
        if (distance <= 300000 && !this.globalData.fiveMinuteAlertShown) {
          this.showGlobalFiveMinuteAlert();
          this.globalData.fiveMinuteAlertShown = true;
        }
      } else {
        // 如果当前时间已超过选择的时间，清除倒计时并初始化变量
        clearInterval(this.globalData.countdownInterval);
        this.globalData.countdown = '';
        this.globalData.chosenTime = null;
        this.globalData.alertShown = false;
        this.globalData.fiveMinuteAlertShown = false;
      }
    },
    showGlobalAlert: function() {
      wx.showModal({
        title: '提示',
        content: '距离检票时间还有10分钟！',
        showCancel: false,
        success: function(res) {
          if (res.confirm) {
            // 用户点击了确定按钮
            // 继续倒计时
          }
        }
      });
    },
    showGlobalFiveMinuteAlert: function() {
      wx.showModal({
        title: '提示',
        content: '距离检票时间还有5分钟！',
        showCancel: false,
        success: function(res) {
          if (res.confirm) {
            // 用户点击了确定按钮
            // 继续倒计时
          }
        }
      });
    }
  });