import mqtt from'../../utils/mqtt.js';
const app = getApp();
const aliyunOpt = require('../../utils/aliyun/aliyun_connect.js');
let that = null;

Page({
    data:{
      Lock : 0,  //0标志关闭状态，1表示打开状态

      startTime: 0, // 计时开始时间
      formattedTime: '00:00:00' ,// 格式化后的时间
      //BoxSwitch:0,//记录箱子开关

    },
    

// 计时器内容开始
startTimer: function() {
  if (!this.data.pausedTime) {
    // 如果没有暂停时间，则重新开始计时
    this.setData({
      startTime: Date.now()
    });
  } else {
    // 如果有暂停时间，则从暂停时间点继续计时
    this.setData({
      startTime: Date.now() - this.data.pausedTime
    });
  }

  // 设置定时器，每秒更新一次elapsedTime
  this.intervalId = setInterval(() => {
    const elapsedTime = Date.now() - this.data.startTime;
    this.updateFormattedTime(elapsedTime);
    // 检查是否已经存储了30min
    /*if (elapsedTime >= 30 * 60 * 1000) {
      this.showThirtyMinutesAlert();
      this.stopTimer(); // 停止计时器
    }*/

  }, 1000);
},

// 暂停计时的函数
pauseTimer: function() {
  if (this.intervalId) {
    clearInterval(this.intervalId);
    // 保存当前的elapsedTime
    this.setData({
      pausedTime: Date.now() - this.data.startTime
    });
  }
},

// 恢复计时的函数
resumeTimer: function() {
  if (this.data.pausedTime) {
    // 如果有暂停时间，则从暂停时间点继续计时
    this.startTimer();
  }
},

// 停止计时的函数
stopTimer: function() {
  if (this.intervalId) {
    clearInterval(this.intervalId);
  }

  // 清零
  this.setData({
    startTime: 0,
    pausedTime: 0,
    formattedTime: '00:00:00'
  });
},

// 更新格式化时间的函数
updateFormattedTime: function(elapsedTime) {
  let totalSeconds = Math.floor(elapsedTime / 1000);
  let hours = Math.floor(totalSeconds / 3600);
  let minutes = Math.floor((totalSeconds % 3600) / 60);
  let seconds = totalSeconds % 60;

  // 格式化时间字符串
  let formattedHours = hours.toString().padStart(2, '0');
  let formattedMinutes = minutes.toString().padStart(2, '0');
  let formattedSeconds = seconds.toString().padStart(2, '0');

  this.setData({
    formattedTime: `${formattedHours}:${formattedMinutes}:${formattedSeconds}`
  });
},
/*
// 显示30分钟提示框的函数
showThirtyMinutesAlert: function() {
  wx.showModal({
    title: '提示',
    content: '你已存储30分钟，请尽快取走',
    success: function (res) {
      if (res.confirm) {//这里是点击了确定以后
        console.log('用户点击确定')
      } else {//这里是点击了取消以后
        console.log('用户点击取消')
      }
    }
  })
},
*/
// 计时器内容结束

  onscan() {
    // 检查app.globalData.aliyunInfo的所有属性是否都有值
    const aliyunInfo = app.globalData.aliyunInfo;
    const isEmpty = !aliyunInfo.productKey || !aliyunInfo.deviceName || !aliyunInfo.deviceSecret || !aliyunInfo.regionId || !aliyunInfo.pubTopic || !aliyunInfo.subTopic;
  
    // 如果为空，则跳转到扫码界面
    if (isEmpty) {
      const app = getApp();
      console.log(app.globalData.BoxNumber); // 读取 BoxNumber
      app.globalData.BoxNumber = 0; // 更新 BoxNumber
      this.stopTimer();
      wx.navigateTo({
        url: '../scan/scan'
      });
      
    } else {
      // 如果不为空，则弹窗提示用户
      wx.showToast({
        title: '您当前已有一个柜子正在使用了哦',
        icon: 'none',
        duration: 2000
      });
    }
  },


  onClickOpen() {
    // 获取全局app实例
    const app = getApp();
    // 根据BoxSwitch的值进行不同的操作
    if (app.globalData.BoxSwitch === 0) {
      // BoxSwitch为0时，设置为1，并弹出提示“柜门已成功打开”
      app.globalData.BoxSwitch = 1;
      wx.showToast({
        title: app.globalData.BoxNumber +'号柜门已打开',
        icon: 'success',
        duration: 2000
      });
      // 发送命令
      this.sendCommond(1);
      //1s之后回退1页
    } else if (app.globalData.BoxSwitch === 1) {
      // BoxSwitch为1时，弹出提示“柜门已处于打开状态”
      wx.showToast({
        title: app.globalData.BoxNumber +'号柜门已处于打开状态',
        icon: 'none',
        duration: 2000
      });
      // 不发送命令，因为状态未改变
    }
  },
  sendCommond(data) {
    const client = app.globalData.mqttClient;
    if (!app.globalData.isConnected) {
      wx.showToast({
        title: '未连接到服务器',
        icon: 'none',
        duration: 2000
      });
      return; // 如果未连接，则不发送消息
    }
    let sendData = {
      BoxSwitch: data,
    };

    // 发布消息到服务器
    // 发布消息到服务器
    app.globalData.mqttClient.publish(app.globalData.aliyunInfo.pubTopic, JSON.stringify(sendData));
    console.log("发布消息到主题:", app.globalData.aliyunInfo.pubTopic);
    console.log("发布的消息内容:", JSON.stringify(sendData));
  },

  laiqubao() {
    // 检查app.globalData.aliyunInfo的所有属性是否都有值
    const aliyunInfo = app.globalData.aliyunInfo;
    const isEmpty = !aliyunInfo.productKey || !aliyunInfo.deviceName || !aliyunInfo.deviceSecret || !aliyunInfo.regionId || !aliyunInfo.pubTopic || !aliyunInfo.subTopic;
  
    // 如果为空，则提示您还未使用储物柜
    if (isEmpty) { 
      wx.showToast({
        title: '您还未使用任何储物柜哦',
        icon: 'none',
        duration: 2000
      });
    } else {
      let that = this;
      const app = getApp();
      // 如果条件不满足，则显示确认弹窗
      wx.showModal({
        title: '确认操作',
        content: '您是否确认打开'+app.globalData.BoxNumber +'号柜门？',
        confirmText: "确认",
        cancelText: "取消",
        success: function (res) {
          if (res.confirm) {
            that.onClickOpen();
            console.log('用户点击确认');
            that.pauseTimer();
             // 使用setInterval来定期检查BoxSwitch的值
          const intervalId = setInterval(() => {
            if (app.globalData.BoxSwitch === 1) {
              // 如果BoxSwitch为1，继续检测
              console.log('BoxSwitch为1，继续检测');
            } else if (app.globalData.BoxSwitch === 0) {
              // 如果BoxSwitch为0，清除定时器，置空aliyunInfo并退出
              clearInterval(intervalId);
              app.globalData.aliyunInfo = {
                productKey: '',
                deviceName: '',
                deviceSecret: '',
                regionId: '',
                pubTopic: '',
                subTopic: ''
              };
              const client = app.globalData.mqttClient;
              console.log('BoxSwitch为0，已将aliyunInfo置空');
              // 断开与云端的连接
              client.end();
              app.globalData.isConnected = false;
              console.log(app.globalData.isConnected);
            }
          }, 1000); // 每秒检查一次
          } else if (res.cancel) {
            console.log('用户点击取消');
            // 这里可以处理用户取消的操作
          }
        }
      });
    }
  },

  
  onShow: function() {
    // 当页面显示时，将全局变量BoxNumber赋值到当前界面的data.BoxNumber中
    const app = getApp();
    this.setData({
      BoxNumber: app.globalData.BoxNumber
    });
    console.log('onShow:', this.data.BoxNumber);
  },



  onLoad: function(options) {
    const app = getApp();

    // 监听 fireWarningUpdated 事件
    app.eventEmitter.on('fireWarningUpdated', (data) => {
      if (data.FireWarning === 1) {
        app.showFireWarningAlert('检测到火焰报警，请立即处理！');
      }
    });
  },
  onUnload: function() {
    const app = getApp();
    // 页面卸载时移除事件监听器
    app.eventEmitter.off('fireWarningUpdated');
  },
})