// mine.js
const app = getApp()

Page({
  data: {
    //items: [ { name: '检票时间选择', value: 'dateTime' }],
    mode: 'dateTime',
    countdown: '',
  },
    onPickerChange(e) {
      const value = e.detail.value;
      // 将日期时间字符串转换为iOS支持的格式
      const iosCompatibleValue = value.replace(/-/g, '/').replace('T', ' '); 
      const chosenTime = new Date(iosCompatibleValue).getTime();

    // 检查选择的时间是否小于当前时间
    if (chosenTime < new Date().getTime()) {
      wx.showModal({
        title: '错误',
        content: '请选择一个大于当前时间的时间。',
        showCancel: false,
      });
    } else {
      app.globalData.chosenTime = chosenTime;
      app.globalData.alertShown = false;
      app.globalData.fiveMinuteAlertShown = false;
      app.startGlobalCountdown();
    }
  },

  onLoad: function() {
    // 初始化倒计时
    this.setData({
      countdown: app.globalData.countdown
    });
    // 监听 fireWarningUpdated 事件
    app.eventEmitter.on('fireWarningUpdated', (data) => {
      if (data.FireWarning === 1) {
        app.showFireWarningAlert('检测到火焰报警，请立即处理！');
      }
    });
  },
  
  onShow: function() {
        // 初始化倒计时
        this.setData({
          countdown: app.globalData.countdown
        });
        console.log(this.data.countdown);
    // 设置倒计时监听器
    this.updateCountdownListener = setInterval(() => {
      this.setData({
        countdown: app.globalData.countdown
      });
    }, 1000);
  },
  
  onHide: function() {
    // 清除倒计时监听器
    clearInterval(this.updateCountdownListener);
  },
  onUnload: function() {
    // 清除倒计时监听器
    clearInterval(this.updateCountdownListener);
  }
});
