import mqtt from '../../utils/mqtt.js';
const app = getApp();
const aliyunOpt = require('../../utils/aliyun/aliyun_connect.js');

//let that = null;

Page({
  data: {
    result: '', // 用于存储扫描结果
    client: null, //记录重连的次数
    reconnectCounts: 0, //MQTT连接的配置
        seats: [false, false, false, false, false, true, false, false, false, true, false, true, false, true, false, true, false, false, false, false, true, false, false, true, false, false, true, false, false, false, false, true, false, true, false, true] // true表示座位被占用，false表示可用
  },

  // 扫描二维码
  scanCode: function () {
    wx.scanCode({
      success: (res) => {
        try {
          // 尝试解析二维码数据为 JSON
          const deviceInfo = JSON.parse(res.result);
          // 更新全局变量
          app.globalData.aliyunInfo = {
            productKey: deviceInfo.productKey,
            deviceName: deviceInfo.deviceName,
            deviceSecret: deviceInfo.deviceSecret,
            regionId: deviceInfo.regionId || '', // 确保regionId有值
            pubTopic: deviceInfo.pubTopic,
            subTopic: deviceInfo.subTopic
          };
          // 打印更新后的全局变量
          console.log('扫码后更新全局变量:', app.globalData.aliyunInfo);
          // 更新页面数据
          this.setData({
            result: res.result,
          });
          // 立即尝试连接MQTT服务器
          this.connectToMqttServer();
        } catch (e) {
          // 如果解析失败，显示错误信息
          console.error('解析二维码数据失败:', e);
          wx.showToast({
            title: '二维码数据格式错误',
            icon: 'none',
            duration: 2000
          });
        }
      }
    })
  },
  // 连接MQTT服务器
  connectToMqttServer: function () {
    let clientOpt = aliyunOpt.getAliyunIotMqttClient({
      productKey: app.globalData.aliyunInfo.productKey,
      deviceName: app.globalData.aliyunInfo.deviceName,
      deviceSecret: app.globalData.aliyunInfo.deviceSecret,
      regionId: app.globalData.aliyunInfo.regionId,
      pubTopic: app.globalData.aliyunInfo.pubTopic,
      subTopic: app.globalData.aliyunInfo.subTopic
    });


    console.log("get data:" + JSON.stringify(clientOpt));
    let host = 'wxs://' + clientOpt.host;

    this.setData({
      'options.clientId': clientOpt.clientId,
      'options.password': clientOpt.password,
      'options.username': clientOpt.username,
      'options.keepalive': 60,// 设置心跳间隔为60秒
    })
    console.log("this.data.options host:" + host);
    console.log("this.data.options data:" + JSON.stringify(this.data.options));

    // 访问服务器
    this.data.client = mqtt.connect(host, this.data.options);


    app.globalData.mqttClient = this.data.client; // 存储客户端实例
    
    
    this.data.client.on('connect', function (connack) {
      wx.showToast({
        title: '连接成功'
      })
      console.log("连接成功");
      app.globalData.isConnected = true; // 设置全局连接状态为已连接
      console.log(app.globalData.isConnected);
    })

    // 接收消息监听
this.data.client.on("message", (topic, payload) => {
  // message是一个16进制的字节流
  let dataFromALY = {};
  try {
    dataFromALY = JSON.parse(payload);
    console.log(dataFromALY);

    // 确保字段存在并有值
    if (typeof dataFromALY.BoxSwitch !== 'undefined') {
      const app = getApp();
      app.globalData.BoxSwitch = dataFromALY.BoxSwitch;
      
    // 检查 BoxSwitch 的值
    if (dataFromALY.BoxSwitch === 0) {
      // 如果 BoxSwitch 为 0，则弹出提示
      wx.showToast({
        title: app.globalData.BoxNumber +'号柜门已关闭',
        icon: 'success',
        duration: 3500
      });
      setTimeout(() => {
        wx.navigateBack({
          delta: 1, // 回退前 delta(默认为1) 页面
        })
      }, 1000);
    }
    // 1s之后回退1页
      }


    // 确保字段存在并有值
    if (typeof dataFromALY.BoxNumber !== 'undefined') {
      const app = getApp();
      app.globalData.BoxNumber = dataFromALY.BoxNumber; // 更新全局变量 BoxNumber
      const BoxNumber = dataFromALY.BoxNumber; // 获取BoxNumber

      // 获取当前页面的seats数组
      let seats = this.data.seats;

      // 检查BoxNumber是否在数组范围内
      if (BoxNumber >= 0 && BoxNumber < seats.length) {
        // 更新对应柜门的状态为已占用
        seats[BoxNumber-1] = true;

        // 更新页面上的seats数据
        this.setData({
          seats: seats
        });
      } else {
        console.error('BoxNumber超出数组范围');
      }
    }


// 检查 FireWarning 是否存在并更新全局变量
if (typeof dataFromALY.FireWarning !== 'undefined') {
  const app = getApp();
  // 监听 FireWarning 的变化
  if (app.globalData.FireWarning !== dataFromALY.FireWarning) {
    // 当接收到的 FireWarning 为1时，更新全局变量 FireWarning
    if (dataFromALY.FireWarning === 1) {
      app.globalData.FireWarning = dataFromALY.FireWarning;
      // 发出事件，通知其他页面或组件 FireWarning 的值已更新
     app.eventEmitter.emit('fireWarningUpdated', {
      FireWarning: 1,
      //FireWarning2: app.globalData.FireWarning2
    });
    } else if (dataFromALY.FireWarning === 0) {
      // 当接收到的 FireWarning 为0时，修改 FireWarning 为0的同时修改全局变量 FireWarning2 为1
      app.globalData.FireWarning = dataFromALY.FireWarning;
      //app.globalData.FireWarning2 = 1;
      // 发出事件，通知其他页面或组件 FireWarning 的值已更新
     app.eventEmitter.emit('fireWarningUpdated', {
      FireWarning: 0,
      //FireWarning2: app.globalData.FireWarning2
    });
    }

    // 更新页面上的 FireWarning 数据
    /*this.setData({
      FireWarning: app.globalData.FireWarning
    });*/

     // 发出事件，通知其他页面或组件 FireWarning 的值已更新
     app.eventEmitter.emit('fireWarningUpdated', {
      FireWarning: app.globalData.FireWarning,
      //FireWarning2: app.globalData.FireWarning2
    });
  }
}

    // ...（其他代码保持不变）

  } catch (error) {
    console.log(error);
  }
    })


    //服务器连接异常的回调
    this.data.client.on("error", function (error) {
      console.log(" 服务器 error 的回调" + error);
      app.globalData.isConnected = false;
      // 在出错时，可以设置一个延迟重试的逻辑
      setTimeout(() => {
      if (!app.globalData.isConnected) {
        this.connectToMqttServer();
      }
    }, 500); // 0.5秒后重试
    })
    //服务器重连连接异常的回调
    this.data.client.on("reconnect", function () {
      console.log(" 服务器 reconnect的回调");
      app.globalData.isConnected = false;
      
    })
    this.data.client.on("offline", () => {
      console.log(" 服务器 offline 的回调");
      app.globalData.isConnected = false;
      // 在断开连接时，可以设置一个延迟重试的逻辑
      setTimeout(() => {
        if (!app.globalData.isConnected) {
          this.connectToMqttServer();
        }
      }, 500); // 0.5秒后重试
    });

    wx.showModal({
      title: '提示',
      content: '是否确认打开该柜门？',
      confirmText: '是',
      cancelText: '否',
      success: (res) => {
        if (res.confirm) {
          // 用户点击了“是”
          console.log('用户确认打开该柜门');
          // 调用函数发送命令
          if (app.globalData.isConnected) {
            this.onClickOpen();
            // 获取当前页面栈
            const pages = getCurrentPages();
            // 找到index页面实例
            const indexPage = pages.find(page => page.route === 'pages/index/index');
            if (indexPage) {
              // 调用index页面的startTimer方法
              indexPage.startTimer();
            } else {
              // 如果index页面不在栈中，您可以采取其他措施，比如显示错误消息
              wx.showToast({
                title: '无法找到index页面',
                icon: 'none',
                duration: 2000
              });
            }
          } else {
            wx.showToast({
              title: '请先连接服务器',
              icon: 'none',
              duration: 2000
            });
          }
        } else if (res.cancel) {
          // 用户点击了“取消”
          console.log('用户取消打开该柜门');
          wx.showToast({
            title: '连接失败',
            icon: 'none',
            duration: 2000
          });
          this.data.client.end();
          app.globalData.isConnected = false;
          console.log(app.globalData.isConnected);
          // 将app.globalData.aliyunInfo全部设置为空
          app.globalData.aliyunInfo = {
            productKey: '',
            deviceName: '',
            deviceSecret: '',
            regionId: '',
            pubTopic: '',
            subTopic: ''           
          };
          console.log(app.globalData.aliyunInfo);
        }
      }
    });

},




  onShow: function () {
    // 打印全局变量aliyunInfo的内容
    console.log('进入页面时全局变量aliyunInfo:', app.globalData.aliyunInfo);
     // 设置网络状态变化监听器
     wx.onNetworkStatusChange((res) => {
      if (res.isConnected) {
        // 如果网络连接恢复了，且 MQTT 客户端未连接，则尝试重新连接
        if (!app.globalData.isConnected) {
          this.connectToMqttServer();
        }
      } else {
        // 如果网络断开，且 MQTT 客户端已连接，则断开连接
        if (app.globalData.isConnected) {
          this.data.client.end();
          app.globalData.isConnected = false;
        }
      }
    });
  },


  onClickOpen() {
    // 获取全局app实例
    const app = getApp();
    // 根据BoxSwitch的值进行不同的操作
    if (app.globalData.BoxSwitch === 0) {
      // BoxSwitch为0时，设置为1，并弹出提示“柜门已成功打开”
      app.globalData.BoxSwitch = 1;
      wx.showToast({
        title: '柜门已成功打开',
        icon: 'success',
        duration: 2000
      });
      // 发送命令
      this.sendCommond(1);
    } else if (app.globalData.BoxSwitch === 1) {
      // BoxSwitch为1时，弹出提示“柜门已处于打开状态”
      wx.showToast({
        title: app.globalData.BoxNumber+'柜门已处于打开状态',
        icon: 'none',
        duration: 2000
      });
      // 不发送命令，因为状态未改变
    }
  },


  sendCommond(data) {
    if (!app.globalData.isConnected) {
      wx.showToast({
        title: '未连接到服务器',
        icon: 'none',
        duration: 2000
      });
      return; // 如果未连接，则不发送消息
    }
    let sendData = {
      BoxSwitch: data,
    };

    //此函数是订阅的函数，因为放在访问服务器的函数后面没法成功订阅topic，因此把他放在这个确保订阅topic的时候已成功连接服务器
//订阅消息函数，订阅一次即可 如果云端没有订阅的话，需要取消注释，等待成功连接服务器之后，在随便点击（开灯）或（关灯）就可以订阅函数
/*     this.data.client.subscribe(this.data.aliyunInfo.subTopic,function(err){
      if(!err){
        console.log("订阅成功");
      };
      wx.showModal({
        content: "订阅成功",
        showCancel: false,
      })
    })  */
    // 发布消息到服务器
    // 发布消息到服务器
    this.data.client.publish(app.globalData.aliyunInfo.pubTopic, JSON.stringify(sendData));
    console.log("发布消息到主题:", app.globalData.aliyunInfo.pubTopic);
    console.log("发布的消息内容:", JSON.stringify(sendData));
  },
  onLoad: function() {
    // 初始化倒计时
    this.setData({
      countdown: app.globalData.countdown
    });
    // 监听 fireWarningUpdated 事件
    app.eventEmitter.on('fireWarningUpdated', (data) => {
      if (data.FireWarning === 1) {
        app.showFireWarningAlert('检测到火焰报警，请立即处理！');
      }
    });
  },
});