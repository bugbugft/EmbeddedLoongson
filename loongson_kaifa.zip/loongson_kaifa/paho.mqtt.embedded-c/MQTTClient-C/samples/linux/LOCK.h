#ifndef _LOCK_H 
#define _LOCK_H 
#include <stdlib.h>
#include <unistd.h>
#include "GPIO.h"

#define loonson_duan1 38
#define loonson_duan2 55

void Lock(int lock)
{
	if(lock == 1)
	{
		system("echo \"init gpio\"");
		GPIO_outset(loonson_duan1);
		system("echo \"lock on\"");
		GPIO_setvalue(loonson_duan1,1);
		usleep(1000000);
		system("echo \"lock off\"");
		GPIO_setvalue(loonson_duan1,0);
		usleep(500000);
		GPIO_off(loonson_duan1);
	}
	else if(lock == 2)
	{
		system("echo \"init gpio\"");
		GPIO_outset(loonson_duan2);
		system("echo \"lock on\"");
		GPIO_setvalue(loonson_duan2,1);
		usleep(1000000);
		system("echo \"lock off\"");
		GPIO_setvalue(loonson_duan2,0);
		usleep(500000);
		GPIO_off(loonson_duan2);
	}
	
}


#endif
