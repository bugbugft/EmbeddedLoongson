#ifndef _DATA_P_H 
#define _DATA_P_H 
#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include "LOCK.h"
#include "VIOCE.h"
#include "GPIO.h"

int voice=1;

int Data_processing(char (*receivedMessages)[100],char (*receivedMessagestopic)[100],int receivedMessagesCount)
{
	/*if (strstr(receivedMessages[receivedMessagesCount], "\"LightStatus\":1") != NULL) 
	{
            	printf("消息解析: %d: 开灯\n", receivedMessagesCount + 1);// 输出“开灯”
        }
        
        else if (strstr(receivedMessages[receivedMessagesCount], "\"LightStatus\":0") != NULL) 
        {
            	printf("消息解析: %d: 关灯\n", receivedMessagesCount + 1);// 检查消息中是否包含 "light:0",输出“关灯”
        }*/
        if (strstr(receivedMessages[receivedMessagesCount], "\"BoxSwitch\":1") != NULL) 
        {
        	if((strstr(receivedMessagestopic[receivedMessagesCount], "/k1b7vpEYB1h/loongson_duan/user/loongson_duan_IAO"))!= NULL)
        	{
        		printf("消息解析: %d: 柜门0001：开锁\n", receivedMessagesCount + 1);
            		Lock(1);
            		if(voice==0) 
            		{
            			vioce_lockedopen_ti();
  				voice=1;
            		}
            		else if(voice==1)
            		{
            			vioce_lockedopen_to();
  				voice=0;
			}
			return 1;
        	}
        	else if((strstr(receivedMessagestopic[receivedMessagesCount], "/k1b7vpEYB1h/loongson_duan/user/loongson_duan2_IAO")) != NULL)
        	{
        		printf("消息解析: %d: 柜门0002：开锁\n", receivedMessagesCount + 1);
            		Lock(2);
            		if(voice==0) 
            		{
            			vioce_lockedopen_ti();
  				voice=1;
            		}
            		else if(voice==1)
            		{
            			vioce_lockedopen_to();
  				voice=0;
			}
			return 2;
        	}
            	
        }
        else if (strstr(receivedMessages[receivedMessagesCount], "\"BoxSwitch\":0") != NULL) 
        {
            	printf("消息解析: %d: 关锁\n", receivedMessagesCount + 1);
            	return -1;
            	
        }
        else 
        {
            	printf("消息解析: %d: 无法识别的命令\n", receivedMessagesCount + 1);// 输出无法识别的消息
            	return -1;
        }
}

#endif
