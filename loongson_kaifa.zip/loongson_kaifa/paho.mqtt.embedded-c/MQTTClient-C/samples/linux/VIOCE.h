#ifndef _VIOCE_H 
#define _VIOCE_H 
#include <stdlib.h>
#include <unistd.h>
#include "GPIO.h"

#define lockop_ti 45
#define lockop_to 46
#define lockop_warn 47
void vioce_lockedopen_ti()
{
	GPIO_outset(lockop_ti);
	GPIO_setvalue(lockop_ti,1);
	usleep(500000);
	GPIO_setvalue(lockop_ti,0);
	usleep(500000);
	GPIO_off(lockop_ti);

}

void vioce_lockedopen_to()
{
	GPIO_outset(lockop_to);
	GPIO_setvalue(lockop_to,1);
	usleep(500000);
	GPIO_setvalue(lockop_to,0);
	usleep(500000);
	GPIO_off(lockop_to);

}
void vioce_warning()
{
	GPIO_outset(lockop_warn);
	GPIO_setvalue(lockop_warn,1);
	usleep(500000);
	GPIO_setvalue(lockop_warn,0);
	usleep(500000);
	GPIO_off(lockop_warn);

}
void vioce_longtime()
{
	GPIO_outset(47);
	GPIO_setvalue(47,1);
	usleep(500000);
	GPIO_setvalue(47,0);
	usleep(500000);
	GPIO_off(47);

}
#endif
