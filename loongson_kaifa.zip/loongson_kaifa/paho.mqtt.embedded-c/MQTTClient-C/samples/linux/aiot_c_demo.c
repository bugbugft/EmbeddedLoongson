#include <stdio.h>
#include <memory.h>
#include "MQTTClient.h"
#include "Data_processing.h"
#include "LOCK.h"
#include "VIOCE.h"
#include "GPIO.h"
#include "FIRE.h"

#include <signal.h>
#include <sys/time.h>
#include <string.h>
#include <stdbool.h>

#define EXAMPLE_PRODUCT_KEY			"k1b7vpEYB1h"
#define EXAMPLE_DEVICE_NAME1			"loongson_duan"
#define EXAMPLE_DEVICE_NAME2			"loongson_duan2"
#define EXAMPLE_DEVICE_SECRET       "65c76d7379615262bb41c4fce17adc78"
#define MAX_MESSAGES 100  // 定义数组大小


int boxnum=-1;
char receivedMessages[MAX_MESSAGES][100]; // 全局数组用于存储接收到的消息,假设每条消息不超过 100 个字符
char receivedMessagestopic[MAX_MESSAGES][100];
int receivedMessagesCount = 0;// 全局变量用于跟踪接收到的消息数量

/* declare the external function aiotMqttSign() */
extern int aiotMqttSign(const char *productKey, const char *deviceName, const char *deviceSecret, 
                     	char clientId[150], char username[65], char password[65]);

volatile int toStop = 0;

void cfinish(int sig)
{
	signal(SIGINT, NULL);
	toStop = 1;
}

void Reset()//重置程序对开发板的控制
{
	GPIO_off(37);
	GPIO_off(40);
	GPIO_off(41);
	GPIO_off(49);

	GPIO_off(56);
	GPIO_off(57);
	GPIO_off(58);
	GPIO_off(59);
	
	GPIO_off(60);
}

void messageArrived(MessageData* md)
{
	MQTTMessage* message = md->message;

	printf("收到消息主题:%.*s\t\n", md->topicName->lenstring.len, md->topicName->lenstring.data);
	printf("收到消息内容:%.*s\n", (int)message->payloadlen, (char*)message->payload);
	
	 // 确保接收消息的数量未超过数组大小
    	if (receivedMessagesCount >= MAX_MESSAGES) 
    	{
    		receivedMessagesCount=1;
    	}
        snprintf(receivedMessages[receivedMessagesCount], sizeof(receivedMessages[0]), "%.*s", (int)message->payloadlen, (char*)message->payload);// 将接收到的消息复制到数组中
        snprintf(receivedMessagestopic[receivedMessagesCount], sizeof(receivedMessagestopic[0]), "%.*s", md->topicName->lenstring.len, md->topicName->lenstring.data);
        boxnum = Data_processing(receivedMessages,receivedMessagestopic,receivedMessagesCount++);//进入消息处理
		
}

/* main function */
int main(int argc, char** argv)
{
	int rc = 0;

	/* setup the buffer, it must big enough for aliyun IoT platform */
	unsigned char buf[1000];
	unsigned char readbuf[1000];

	Network n;
	MQTTClient c;
	char *host = EXAMPLE_PRODUCT_KEY"k1b7vpEYB1h.iot-as-mqtt.cn-shanghai.aliyuncs.com";
	short port = 1883;

	const char *subTopic = "/"EXAMPLE_PRODUCT_KEY"/"EXAMPLE_DEVICE_NAME1"/user/loongson_duan_IAO";
	const char *subTopic2 = "/"EXAMPLE_PRODUCT_KEY"/"EXAMPLE_DEVICE_NAME1"/user/loongson_duan2_IAO";
	const char *pubTopic_yun1 = "/"EXAMPLE_PRODUCT_KEY"/"EXAMPLE_DEVICE_NAME1"/user/loongson_duan";//云流转平台topic1
	const char *pubTopic_yun2 = "/"EXAMPLE_PRODUCT_KEY"/"EXAMPLE_DEVICE_NAME1"/user/loongson_duan2";//云流转平台topic2
	const char *pubTopic_loongson_duan = "/sys/"EXAMPLE_PRODUCT_KEY"/"EXAMPLE_DEVICE_NAME1"/thing/event/property/post";//阿里云龙芯端
	
	/* invoke aiotMqttSign to generate mqtt connect parameters */
	char clientId[150] = {0};
	char username[65] = {0};
	char password[65] = {0};

	if ((rc = aiotMqttSign(EXAMPLE_PRODUCT_KEY, EXAMPLE_DEVICE_NAME1, EXAMPLE_DEVICE_SECRET, clientId, username, password) < 0)) {
		printf("aiotMqttSign -%0x4x\n", -rc);
		return -1;
	}
	printf("clientid: %s\n", clientId);
	printf("username: %s\n", username);
	printf("password: %s\n", password);

	signal(SIGINT, cfinish);//Ctrl+c后进入处理函数
	signal(SIGTERM, cfinish);

	/* network init and establish network to aliyun IoT platform */
	NetworkInit(&n);
	rc = NetworkConnect(&n, host, port);
	printf("NetworkConnect %d\n", rc);

	/* init mqtt client */
	MQTTClientInit(&c, &n, 1000, buf, sizeof(buf), readbuf, sizeof(readbuf));
 
	/* set the default message handler */
	c.defaultMessageHandler = messageArrived;

	/* set mqtt connect parameter */
	MQTTPacket_connectData data = MQTTPacket_connectData_initializer;       
	data.willFlag = 0;
	data.MQTTVersion = 3;
	data.clientID.cstring = clientId;
	data.username.cstring = username;
	data.password.cstring = password;
	data.keepAliveInterval = 60;
	data.cleansession = 1;
	printf("Connecting to %s %d\n", host, port);

	rc = MQTTConnect(&c, &data);
	printf("MQTTConnect %d, Connect aliyun IoT Cloud Success!\n", rc);
    
    	printf("Subscribing to %s\n", subTopic);
	rc = MQTTSubscribe(&c, subTopic, 1, messageArrived);
	printf("MQTTSubscribe %d\n", rc);
	
	printf("Subscribing to %s\n", subTopic2);
	rc = MQTTSubscribe(&c, subTopic2, 1, messageArrived);
	printf("MQTTSubscribe %d\n", rc);
	
	int cnt = 0;
    	unsigned int msgid = 0;
    	GPIO_outset(37);
    	GPIO_setvalue(37,0);
    	GPIO_outset(41);
    	GPIO_setvalue(41,1);
    	GPIO_outset(49);
    	GPIO_setvalue(49,1);
    	
    	GPIO_outset(56);
    	GPIO_setvalue(56,0);
    	GPIO_outset(58);
    	GPIO_setvalue(58,1);
    	GPIO_outset(59);
    	GPIO_setvalue(59,1);
    	
    	GPIO_inset(57);
    	GPIO_inset(40);
    	
    	GPIO_inset(60);
    	
    	
    	int turn=-1;
    	int turn2=-1;
    	int gpio=1;
    	int gpio2=1;
    	int fire=0;
    	int Fire=-1;
	while (!toStop)
	{
		MQTTYield(&c, 1000);	
		Fire=FIRE();
		if(Fire==1) printf("柜内状态：明火！\n");
		else if (Fire==0) printf("柜内状态：正常\n");
		if(boxnum == 1)
		{
			if(Fire==1&&fire==0)
			{
				fire=1;
				char Firewarning[] = "{\"FireWarning\":1}";
    				char Firewarning_2[] = "{params:{FireWarning:1}}";
				MQTTMessage msg_fire = {QOS1,0,0,0,Firewarning,strlen(Firewarning),};
				MQTTMessage msg_fire2 = {QOS1,0,0,0,Firewarning_2,strlen(Firewarning_2),};
				msg_fire.id = ++msgid;
				rc = MQTTPublish(&c, pubTopic_yun1, &msg_fire);
				rc = MQTTPublish(&c, pubTopic_loongson_duan, &msg_fire2);//测试用
				printf("上报质量： %d, 第 %d条信息：FireWarning=%d——————1号柜明火警报！！\n", rc, msgid, 1);
			}
			else if(Fire==0&&fire==1)
			{
				fire=0;
				char Firewarning[] = "{\"FireWarning\":0}";
    				char Firewarning_2[] = "{params:{FireWarning:0}}";
				MQTTMessage msg_fire = {QOS1,0,0,0,Firewarning,strlen(Firewarning),};
				MQTTMessage msg_fire2 = {QOS1,0,0,0,Firewarning_2,strlen(Firewarning_2),};
				msg_fire.id = ++msgid;
				rc = MQTTPublish(&c, pubTopic_yun1, &msg_fire);
				rc = MQTTPublish(&c, pubTopic_loongson_duan, &msg_fire2);//测试用
				printf("上报质量： %d, 第 %d条信息：FireWarning=%d——————1号柜柜内正常。\n", rc, msgid, 0);
			}
		}
		else if(boxnum == 2)
		{
			if(Fire==1&&fire==0)
			{
				fire=1;
				char Firewarning[] = "{\"FireWarning\":1}";
    				char Firewarning_2[] = "{params:{FireWarning:1}}";
				MQTTMessage msg_fire = {QOS1,0,0,0,Firewarning,strlen(Firewarning),};
				MQTTMessage msg_fire2 = {QOS1,0,0,0,Firewarning_2,strlen(Firewarning_2),};
				msg_fire.id = ++msgid;
				rc = MQTTPublish(&c, pubTopic_yun2, &msg_fire);
				rc = MQTTPublish(&c, pubTopic_loongson_duan, &msg_fire2);//测试用
				printf("上报质量： %d, 第 %d条信息：FireWarning=%d——————2号柜明火警报！！\n", rc, msgid, 1);
			}
			else if(Fire==0&&fire==1)
			{
				fire=0;
				char Firewarning[] = "{\"FireWarning\":0}";
    				char Firewarning_2[] = "{params:{FireWarning:0}}";
				MQTTMessage msg_fire = {QOS1,0,0,0,Firewarning,strlen(Firewarning),};
				MQTTMessage msg_fire2 = {QOS1,0,0,0,Firewarning_2,strlen(Firewarning_2),};
				msg_fire.id = ++msgid;
				rc = MQTTPublish(&c, pubTopic_yun2, &msg_fire);
				rc = MQTTPublish(&c, pubTopic_loongson_duan, &msg_fire2);//测试用
				printf("上报质量： %d, 第 %d条信息：FireWarning=%d——————2号柜柜内正常。\n", rc, msgid, 0);
			}
		}
		gpio=GPIO_getvalue(40);
		gpio2=GPIO_getvalue(57);
		
		if(gpio==1) printf("0001柜门状态：关闭\n");
		else if (gpio==0) printf("0001柜门状态：开启\n");
		if(gpio2==1) printf("0002柜门状态：关闭\n\n");
		else if (gpio2==0) printf("0002柜门状态：开启\n\n");
		if(turn!=gpio||turn2!=gpio2)
		{
			turn=gpio;
			turn2=gpio2;
			if(boxnum == 1)
			{
				if(gpio==1)
				{
					char BoxSwitch1[] = "{\"BoxSwitch\":0}";
					char BoxSwitch2[] = "{params:{BoxSwitch:0}}";
					char BoxSwitch3[] = "{\"BoxNumber\":0001}";
					char BoxSwitch4[] = "{params:{BoxNumber:0001}}";
					MQTTMessage msg = {QOS1,0,0,0,BoxSwitch1,strlen(BoxSwitch1),};
					MQTTMessage msg2 = {QOS1,0,0,0,BoxSwitch2,strlen(BoxSwitch2),};//测试用
					MQTTMessage msg3 = {QOS1,0,0,0,BoxSwitch3,strlen(BoxSwitch3),};
					MQTTMessage msg4 = {QOS1,0,0,0,BoxSwitch4,strlen(BoxSwitch4),};
            				msg.id = ++msgid;
					rc = MQTTPublish(&c, pubTopic_yun1, &msg);
					rc = MQTTPublish(&c, pubTopic_yun1, &msg3);
					rc = MQTTPublish(&c, pubTopic_loongson_duan, &msg2);//测试用
					rc = MQTTPublish(&c, pubTopic_loongson_duan, &msg4);
					printf("上报质量： %d, 第 %d条信息：BoxSwitch=%d——————1号柜柜门关闭\n", rc, msgid, 0);
				}
				else if(gpio==0)
				{
					char BoxSwitch1[] = "{\"BoxSwitch\":1}";
					char BoxSwitch2[] = "{params:{BoxSwitch:1}}";
					char BoxSwitch3[] = "{\"BoxNumber\":0001}";
					char BoxSwitch4[] = "{params:{BoxNumber:0001}}";
					MQTTMessage msg = {QOS1,0,0,0,BoxSwitch1,strlen(BoxSwitch1),};
					MQTTMessage msg2 = {QOS1,0,0,0,BoxSwitch2,strlen(BoxSwitch2),};//测试用
					MQTTMessage msg3 = {QOS1,0,0,0,BoxSwitch3,strlen(BoxSwitch3),};
					MQTTMessage msg4 = {QOS1,0,0,0,BoxSwitch4,strlen(BoxSwitch4),};
            				msg.id = ++msgid;
					rc = MQTTPublish(&c, pubTopic_yun1, &msg);
					rc = MQTTPublish(&c, pubTopic_yun1, &msg3);
					rc = MQTTPublish(&c, pubTopic_loongson_duan, &msg2);//测试用
					rc = MQTTPublish(&c, pubTopic_loongson_duan, &msg4);
					printf("上报质量： %d, 第 %d条信息：BoxSwitch=%d——————1号柜柜门打开\n", rc, msgid, 1);
				}
			}
			if(boxnum == 2)
			{
				if(gpio2==1)
				{
					char BoxSwitch1[] = "{\"BoxSwitch\":0}";
					char BoxSwitch2[] = "{params:{BoxSwitch:0}}";
					char BoxSwitch3[] = "{\"BoxNumber\":0002}";
					char BoxSwitch4[] = "{params:{BoxNumber:0002}}";
					MQTTMessage msg = {QOS1,0,0,0,BoxSwitch1,strlen(BoxSwitch1),};
					MQTTMessage msg2 = {QOS1,0,0,0,BoxSwitch2,strlen(BoxSwitch2),};//测试用
					MQTTMessage msg3 = {QOS1,0,0,0,BoxSwitch3,strlen(BoxSwitch3),};
					MQTTMessage msg4 = {QOS1,0,0,0,BoxSwitch4,strlen(BoxSwitch4),};
            				msg.id = ++msgid;
					rc = MQTTPublish(&c, pubTopic_yun2, &msg);
					rc = MQTTPublish(&c, pubTopic_yun2, &msg3);
					rc = MQTTPublish(&c, pubTopic_loongson_duan, &msg2);//测试用
					rc = MQTTPublish(&c, pubTopic_loongson_duan, &msg4);
					printf("上报质量： %d, 第 %d条信息：BoxSwitch=%d——————2号柜柜门关闭\n", rc, msgid, 0);
				}
				else if(gpio2==0)
				{
					char BoxSwitch1[] = "{\"BoxSwitch\":1}";
					char BoxSwitch2[] = "{params:{BoxSwitch:1}}";
					char BoxSwitch3[] = "{\"BoxNumber\":0002}";
					char BoxSwitch4[] = "{params:{BoxNumber:0002}}";
					MQTTMessage msg = {QOS1,0,0,0,BoxSwitch1,strlen(BoxSwitch1),};
					MQTTMessage msg2 = {QOS1,0,0,0,BoxSwitch2,strlen(BoxSwitch2),};//测试用
					MQTTMessage msg3 = {QOS1,0,0,0,BoxSwitch3,strlen(BoxSwitch3),};
					MQTTMessage msg4 = {QOS1,0,0,0,BoxSwitch4,strlen(BoxSwitch4),};
            				msg.id = ++msgid;
					rc = MQTTPublish(&c, pubTopic_yun2, &msg);
					rc = MQTTPublish(&c, pubTopic_yun2, &msg3);
					rc = MQTTPublish(&c, pubTopic_loongson_duan, &msg2);//测试用
					rc = MQTTPublish(&c, pubTopic_loongson_duan, &msg4);
					printf("上报质量： %d, 第 %d条信息：BoxSwitch=%d——————2号柜柜门打开\n", rc, msgid, 1);
				}
			}
			
		}
		
	}

	printf("Stopping\n");
	Reset();
	MQTTDisconnect(&c);
	NetworkDisconnect(&n);

	return 0;
}
