#ifndef _FIRE_H 
#define _FIRE_H 
#include <stdlib.h>
#include <unistd.h>
#include "GPIO.h"
#include "VIOCE.h"
int Firenum=0;

int FIRE()
{
	int N=GPIO_getvalue(60);
	if(N==0&&Firenum==0)
	{
		Firenum=1;
		vioce_warning();
		return 1;
	}
	else if(N==0&&Firenum==1)
	{
		vioce_warning();
		return 1;
	}
	else if (N==1&&Firenum==1) 
	{
		Firenum=0;
		return 0;
	}
	else return 0;
}


#endif
