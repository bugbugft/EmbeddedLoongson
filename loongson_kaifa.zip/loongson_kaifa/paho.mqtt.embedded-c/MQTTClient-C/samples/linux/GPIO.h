#ifndef _GPIO_H 
#define _GPIO_H 
#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
char A[] = "/sys/class/gpio/gpio";
char B[] = "/value";
char C[] = "/export";
char D[] = "/direction";
char E[] = "/unexport";
void GPIO_outset(int N)
{
    	char command1[100]; // 定义一个足够大的字符数组来存储命令字符串
    	char command2[100];
    	sprintf(command1, "echo %d > /sys/class/gpio/export", N);
    	sprintf(command2, "echo out > /sys/class/gpio/gpio%d/direction", N);
    	system(command1); // 执行命令
    	system(command2);
}
void GPIO_inset(int N)
{
    	char command1[100]; // 定义一个足够大的字符数组来存储命令字符串
    	char command2[100];
    	sprintf(command1, "echo %d > /sys/class/gpio/export", N);
    	sprintf(command2, "echo in > /sys/class/gpio/gpio%d/direction", N);
    	system(command1); // 执行命令
    	system(command2);
}
void GPIO_off(int N)
{
    	char command1[100]; // 定义一个足够大的字符数组来存储命令字符串
    	sprintf(command1, "echo %d > /sys/class/gpio/unexport", N);
    	system(command1); // 执行命令
}
void GPIO_setvalue(int N,int num)
{
    	char command1[100]; // 定义一个足够大的字符数组来存储命令字符串
    	sprintf(command1, "echo %d >  /sys/class/gpio/gpio%d/value",num , N);
    	system(command1); // 执行命令
}
int GPIO_getvalue(int N)
{
	
	int fd;
    	char value;
    // 预估 C 的最大长度，为 A、B、N 以及连接符的总长度
    	int max_length = strlen(A) + strlen(B) + 10; // 10 是为了容纳整数 N 的长度和额外的空间

    // 分配足够的空间给 GPIO_VALUE_PATH
    	char *GPIO_VALUE_PATH = (char *)malloc(max_length * sizeof(char));

    	strcpy(GPIO_VALUE_PATH, A);
    	char str_N[10]; // 假设整数 N 不超过 10 位数
    	sprintf(str_N, "%d", N);
    	strcat(GPIO_VALUE_PATH, str_N);
	strcat(GPIO_VALUE_PATH, B);
    	// 输出结果
    	//printf("String C: %s\n", C);
    	// 释放内存
    	fd = open(GPIO_VALUE_PATH, O_RDONLY);
    	if (fd < 0) {
        	perror("Failed to open GPIO value file");
        	return -1;
    	}

    // 读取 GPIO 值
    	if (read(fd, &value, 1) != 1) {
        	perror("Failed to read GPIO value");
        	close(fd);
        	return -1;
    	}

    // 关闭文件描述符
    	close(fd);
	free(GPIO_VALUE_PATH);
    // 输出 GPIO 值
    	//printf("GPIO %d value: %c\n", N, value);

    	return value-48;
}
#endif
